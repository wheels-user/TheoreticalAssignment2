import java.awt.Color;
import java.awt.Font;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainGUI {

	private JFrame frame;
	private static JTextArea taScreen;
	private static Keypad keypad;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		MainGUI window = new MainGUI();
		window.frame.setVisible(true);
	
		//Thread.currentThread().wait(1000);
		ATM theATM = new ATM(taScreen);
		keypad = theATM.getKeyPad();
		theATM.run();
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();

		
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		manager.addKeyEventPostProcessor((KeyEventPostProcessor) new KeyEventPostProcessor(){
			@Override
			public boolean postProcessKeyEvent(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getID() == KeyEvent.KEY_PRESSED){
					int keyCode = e.getKeyCode();
					if((keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_9)
					|| keyCode >= KeyEvent.VK_NUMPAD0 && keyCode <= KeyEvent.VK_NUMPAD9)
					{
						keypad.numberPressed((keyCode - KeyEvent.VK_NUMPAD0) < 0 ? 
								(keyCode - KeyEvent.VK_0) : (keyCode - KeyEvent.VK_NUMPAD0));
					}
					else if(keyCode == KeyEvent.VK_ENTER)
						keypad.cmdOk();
					else if(keyCode == KeyEvent.VK_DELETE || keyCode == KeyEvent.VK_BACK_SPACE)
						keypad.cmdDelete();
					
					return true;
				}
				return false;
			}
			
		});
		
		
		
		frame.setResizable(false);
		frame.setAutoRequestFocus(true);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\workspace\\ATM\\pic\\ATM.jpg"));
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);

		
		frame.setBounds(100, 100, 1005, 778);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JPanel numberPanel = new JPanel();
		numberPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new BevelBorder(BevelBorder.LOWERED, null, null, null, null)));
		numberPanel.setBackground(Color.LIGHT_GRAY);
		numberPanel.setBounds(63, 406, 391, 324);
		frame.getContentPane().add(numberPanel);
		numberPanel.setLayout(null);
		
		JButton btn1 = new JButton("1");
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(1);
			}
		});
		btn1.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn1.setBounds(27, 22, 56, 44);
		numberPanel.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(2);
			}
		});
		btn2.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn2.setBounds(111, 22, 56, 44);
		numberPanel.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(3);
			}
		});
		btn3.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn3.setBounds(197, 22, 56, 44);
		numberPanel.add(btn3);
		
		JButton btn4 = new JButton("4");
		btn4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(4);
			}
		});
		btn4.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn4.setBounds(27, 93, 56, 44);
		numberPanel.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(5);
			}
		});
		btn5.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn5.setBounds(111, 93, 56, 44);
		numberPanel.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(6);
			}
		});
		btn6.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn6.setBounds(197, 93, 56, 44);
		numberPanel.add(btn6);
		
		JButton btn7 = new JButton("7");
		btn7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(7);
			}
		});
		btn7.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn7.setBounds(27, 161, 56, 44);
		numberPanel.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(8);
			}
		});
		btn8.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn8.setBounds(111, 161, 56, 44);
		numberPanel.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(9);
			}
		});
		btn9.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn9.setBounds(197, 161, 56, 44);
		numberPanel.add(btn9);
		
		JButton btn0 = new JButton("0");
		btn0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(0);
			}
		});
		btn0.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn0.setBounds(111, 231, 56, 44);
		numberPanel.add(btn0);
		
		JButton btnClearNum = new JButton("\u6E05\u9664");
		btnClearNum.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.cmdClear();
			}
		});
		btnClearNum.setBounds(277, 23, 83, 44);
		numberPanel.add(btnClearNum);
		
		JButton btnDelete = new JButton("\u5220\u9664");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.cmdDelete();
			}
		});
		btnDelete.setBounds(277, 94, 83, 44);
		numberPanel.add(btnDelete);
		
		JButton btnClear = new JButton("\u6E05\u5C4F");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnClear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String temp = taScreen.getText();
				int lastIndex = temp.lastIndexOf('\n');
				if(lastIndex > 0)
					temp = temp.substring(lastIndex + 1, temp.length());
				
				System.out.println(lastIndex);
				taScreen.setText(temp);
			}
		});
		btnClear.setBounds(277, 164, 83, 44);
		numberPanel.add(btnClear);
		
		JButton btn00 = new JButton("00");
		btn00.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.numberPressed(0);
				keypad.numberPressed(0);
			}
		});
		btn00.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
		btn00.setBounds(27, 231, 56, 44);
		numberPanel.add(btn00);
		
		JButton btnOK = new JButton("\u786E\u8BA4");
		btnOK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				keypad.cmdOk();
			}
		});
		btnOK.setBounds(277, 232, 83, 44);
		numberPanel.add(btnOK);
		
		JLabel lblȡ��� = new JLabel("1");
		lblȡ���.setForeground(Color.BLACK);
		lblȡ���.setBackground(Color.BLUE);
		lblȡ���.setBounds(516, 413, 397, 99);
		lblȡ���.setIcon(new ImageIcon("D:\\workspace\\ATM\\pic\\\u53D6\u6B3E\u53E3.png"));
		frame.getContentPane().add(lblȡ���);
		
		JLabel lbl���� = new JLabel("");
		lbl����.setIcon(new ImageIcon("D:\\workspace\\ATM\\pic\\\u5B58\u6B3E\u53E3.png"));
		lbl����.setBounds(516, 587, 397, 99);
		//label.
		frame.getContentPane().add(lbl����);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(189, 67, 591, 326);
		frame.getContentPane().add(scrollPane);
		
		taScreen = new JTextArea("The ATM is loading...");
		scrollPane.setViewportView(taScreen);
		taScreen.setForeground(Color.BLACK);
		taScreen.setBackground(Color.GRAY);
		taScreen.setVisible(true);
		//taScreen.setOpaque(true);
		taScreen.setFont(new Font("Consolas", Font.PLAIN, 24));
		taScreen.setLineWrap(true);
		taScreen.setEditable(false);
		
		
	}
}
