

import javax.swing.JTextArea;



// Represents the screen of the ATM
//�������
public class Screen {
	private JTextArea taScreen;
	private String lineSeparator = System.lineSeparator();
	
	public JTextArea getScreen(){
		return taScreen;
	}
	
	public Screen(JTextArea thetaScreen){
		taScreen = thetaScreen;
	}
	
	// display a message without a carriage return
	public void displayMessage(String message) {
		taScreen.append(message);
		taScreen.setCaretPosition(taScreen.getText().length());
	} // end method displayMessage

	// display a message with a carriage return
	public void displayMessageLine(String message) {
		displayMessage(message+lineSeparator);
	} // end method displayMessageLine

	// displays a dollar amount
	public void displayDollarAmount(double amount) {
		displayMessage(String.format("$%,.2f", amount));
	} // end method displayDollarAmount
} // end class Screen